function Switch() {
    var input = parseInt(document.getElementById("input").value);
    var monthName = getMonthName(input);
    document.getElementById("output1").innerText = monthName;
}

function getMonthName(number) {
    switch(number) {
        case 1:
            return "Leden";
        case 2:
            return "Únor";
        case 3:
            return "Březen";
        case 4:
            return "Duben";
        case 5:
            return "Květen";
        case 6:
            return "Červen";
        case 7:
            return "Červenec";
        case 8:
            return "Srpen";
        case 9:
            return "Zaří";
        case 10:
            return "Říjen";
        case 11:
            return "Listopad";
        case 12:
            return "Prosinec";
        default:
            return "Neplatný vstup. Zadejte číslo mezi 1 a 12.";
    }
}

function While() {
    var output2 = document.getElementById("output2");
    var num = 2;

    while (num <= 20) {
        output2.innerHTML += num + ", ";
        num += 2;
    }
}

function Password() {
    var password = "heslo123";
    var output3 = document.getElementById("output3");
    var input = document.getElementById("input3").value;

    if (input === password) {
        output3.innerHTML = "Zadali jste správné heslo.";
    } else {
        output3.innerHTML = "Zadali jste nesprávné heslo.";
    }
}


function Switch2() {
    var input = parseInt(document.getElementById("input4").value);
    var dayName = getDayName(input);
    document.getElementById("output4").innerText = dayName;
}

function getDayName(number) {
    switch(number) {
        case 1:
            return "Pondělí";
        case 2:
            return "Úterý";
        case 3:
            return "Středa";
        case 4:
            return "Čtvrtek";
        case 5:
            return "Pátek";
        case 6:
            return "Sobota";
        case 7:
            return "Neděle";
        default:
            return "Neplatný vstup. Zadejte číslo mezi 1 a 7.";
    }
}

var sum = 0;

function Suma() {
    var input = document.getElementById("input6");
    var output = document.getElementById("output6");
    var number = parseInt(input.value);

    if (number !== 0) {
        sum += number;
    } else {
        output.innerHTML = "Součet všech zadaných čísel je: " + sum;
    }
    input.value = "";
}

function Fibonacci() {
    var a = 0;
    var b = 1;
    var fibonacciSequence = [a, b];

    while (fibonacciSequence.length < 10) {
        var next = a + b;
        fibonacciSequence.push(next);
        a = b;
        b = next;
    }

    var output = document.getElementById("output5");
    output.textContent = fibonacciSequence.join(", ");
}


